import { LitElement, html, css } from 'lit';
import stylesSscss from './mi-componenteStyles';

export class MiComponente extends LitElement {

  render() {
    return html`
      <form action="">
        <div class="box bg-white">
          <div class="colors">
            <h1 class="text-white pt-3">PUMAS DC</h1>
          </div>
          <div class="container-input pt-4">
            <div class="m-5">
              <input
                type="text"
                placeholder="Usuario"
                autofocus 
                pattern="[A-Za-z0-9]{8, 12}"
              />
            </div>
            <div class="text-center m-5">
              <input
                type="password"
                name=""
                id=""
                placeholder="Contraseña"
                pattern="(?=^.{8,}$)((?=.*\\d)|(?=.*\\W+))(?![.\\n])(?=.*[A-Z])(?=.*[a-z]).*$"
                required
              />
            </div>
            <div class="text-center pt-3">
              <button type="submit" class="btn h1 w-50">INGRESAR</button>
            </div>
            <div class="text-center pt-1 mt-2">
              <a class="link" href="#">Olvidó su Contraseña?</a>
            </div>
          </div>
        </div>
      </form>
    `;
  }

  static get styles() {   
    return [stylesSscss];
  }
}

customElements.define('mi-componente', MiComponente);
