import { css } from 'lit';

export default css`
  body {
    background-image: url(../img/Background.png);
    background-repeat: no-repeat;
    background-size: 100% 115%;
    margin: 0;
    font-family: Arial, sans-serif;
  }

  .colors {
    background-color: red;
    width: 100%;
    height: 80px;
    text-align: center;
    border-radius: 20px 20px 0 0;
  }
  
  .box {
    margin: 0 auto;
    margin-top: 10%;
    margin-bottom: 5%;
    position: relative;
    width: 500px;
    height: 430px;
    border-radius: 20px;
    box-shadow: -3px 5px 3px 3px rgba(0, 0, 0, 0.5);
  }
  
  .container-input {
    margin: 0 auto;
    align-items: center;
  }
  
  input {
    font-weight: 600;
    border: none;
    border-bottom: 2px rgb(233, 233, 233) solid;
    width: 100%;
    padding: 8px;
  }
  
  input:focus {
    outline: none;
    border-bottom: 2px red solid;
  }
  
  button {
    background-color: red;
    color: #fff;
    font-weight: 600;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  
  .link {
    font-weight: 700;
    font-size: 14px;
    color: rgb(128, 128, 128);
    text-decoration: none;
  }
  
  .link:hover {
    text-decoration: underline;
  }
`;
