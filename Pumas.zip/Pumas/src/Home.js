import { LitElement, html, css } from 'lit';

class Home extends LitElement {
  render() {
    return html`
      <div>
        <h2>Home</h2>
        
        <nav class="d-flex">
        <div class="d-flex nav">

            <svg class="circle" width="80px" height="80px">
                <circle cx="40" cy="40" r="35" fill="white" />
            </svg>
            <img src="../assets/img/logo2.png" alt="" class="logo">
            <div class="rectangule_outer">
                <div class="rectangule_inner">
                    <h5 class="user">Usuarios</h5>
                </div>
            </div>
        </div>
        <div class="align-items-center m-3  ">
            <div class="dropdown show">
                <button type="button" class="btn btn-secondary ">
                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor"
                        class="bi bi-list" viewBox="0 0 16 16">
                        <path fill-rule="evenodd"
                            d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
                    </svg>
                </button>

                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div>

            </div>

        </div>

    </nav>
    <div class="container text-center mt-3 ">
        <div class="row align-items-start">
            <div class="col menu-horizontal ">
                <div>
                    <button type="button" class="d-flex btn-danger m-2 mt-4 menu-horizontal-contenedores text-start">
                        <h6 class="p-1">Home</h6>
                    </button>
                </div>
                <div>
                    <button type="button" class="d-flex btn-danger m-2 mt-4 menu-horizontal-contenedores text-start">
                        <h6 class="p-1">Presidencia</h6>
                    </button>
                </div>
                <div>
                    <button type="button" class="d-flex btn-danger m-2 mt-4 menu-horizontal-contenedores text-start">
                        <h6 class="p-1">Presidencia</h6>
                    </button>
                </div>
                <div>
                    <button type="button" class="d-flex btn-danger m-2 mt-4 menu-horizontal-contenedores text-start">
                        <h6 class="mt-1">Vice-presidencia</h6>
                    </button>
                </div>
                <div>
                    <button type="button" class="d-flex btn-danger m-2 mt-4 menu-horizontal-contenedores text-start">
                        <h6 class="mt-1">Secretaria</h6>
                    </button>
                </div>
                <div>
                    <button type="button" class="d-flex btn-danger m-2 mt-4 menu-horizontal-contenedores text-start">
                        <h6 class="mt-1">Tesoreria</h6>
                    </button>
                </div>
                <div>
                    <button type="button" class="d-flex btn-danger m-2 mt-4 menu-horizontal-contenedores text-start">
                        <h6 class="mt-1">Revisoria fiscal</h6>
                    </button>
                </div>
                <div>
                    <button type="button" class="d-flex btn-danger m-2 mt-4 mb-4 menu-horizontal-contenedores text-start">
                        <h6 class="mt-1">Lista afiliados</h6>
                    </button>
                </div>
                <div>
                    <button type="button" class="d-flex btn-danger m-2 mt-4 mb-4 menu-horizontal-contenedores text-start">
                        <h6 class="mt-1">Lista jugadores</h6>
                    </button>
                </div>
                <div>
                    <button type="button" class="d-flex btn-danger m-2 mt-4 mb-4 menu-horizontal-contenedores text-start">
                        <img src="../assets/img/iconoBalon.png" alt="" width="5%" class="icon-balon">
                        <h6 class="mt-1">Lista coach's</h6>
                    </button>
                </div>
            </div>
            <div class="col ms-5">
                <div class="card mb-4" style="width: 15rem;height: 15rem;">
                    <div class="m-auto w-75 mt-2">
                        <h5 class="card-title ms-1 subline">Actas</h5>
                    </div>
                    <div class="card-body">
                        <div style='width:100%;height: 80px' class="ratio ratio-1x1 mb-4">
                            <img class="ratio ratio-1x1" src="../assets/img/icon-actas.png" alt=""
                                width="100%" height="70%">
                        </div>
                        <a href="#" class="btn btn-primary">Gestionar</a>
                    </div>

                </div>
                <div class="card mb-3" style="width: 15rem;height: 15rem;">
                    <div class="m-auto w-75 mt-2">

                        <h5 class="card-title ms-1">Asistencia</h5>
                    </div>
                    <div class="card-body">
                        <div style='width:100%;height: 80px' class="ratio ratio-1x1 mb-4">
                            <img class="ratio ratio-1x1" src="../assets/img/ico-asistencia.png" alt=""
                                width="100%" height="70%">
                        </div>
                        <a href="#" class="btn btn-primary">Gestionar</a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-4" style="width: 15rem;height: 15rem;">
                    <div class="m-auto w-75 mt-2">

                        <h5 class="card-title ms-1">Certificados</h5>
                    </div>
                    <div class="card-body">
                        <div style='width:100%;height: 80px' class="ratio ratio-1x1 mb-4">
                            <img class="ratio ratio-1x1" src="../assets/img/icon-certificados.png" alt=""
                                width="100%" height="70%">
                        </div>
                        <a href="#" class="btn btn-primary">Gestionar</a>
                    </div>
                </div>
                <div class="card mb-3" style="width: 15rem;height: 15rem;">
                    <div class="m-auto w-75 mt-2">

                        <h5 class="card-title ms-1">Comunicacion</h5>
                    </div>
                    <div class="card-body">
                        <div style='width:100%;height: 80px' class="ratio ratio-1x1 mb-4">
                            <img class="ratio ratio-1x1" src="../assets/img/ico-mensajes.png" alt=""
                                width="100%" height="70%">
                        </div>
                        <a href="#" class="btn btn-primary">Gestionar</a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-4" style="width: 15rem;height: 15rem;">
                    <div class="m-auto w-75 mt-2">

                        <h5 class="card-title ms-1">Reuniones</h5>
                    </div>
                    <div class="card-body">
                        <div style='width:100%;height: 80px' class="ratio ratio-1x1 mb-4">
                            <img class="ratio ratio-1x1" src="../assets/img/icon-reuniones.png" alt=""
                                width="100%" height="70%">
                        </div>
                        <a href="#" class="btn btn-primary">Gestionar</a>
                    </div>
                </div>
                <div class="card mb-3" style="width: 15rem;height: 15rem;">
                    <div class="m-auto w-75 mt-2">

                        <h5 class="card-title ms-1">Estado de cuenta</h5>
                    </div>
                    <div class="card-body">
                        <div style='width:100%;height: 80px' class="ratio ratio-1x1 mb-4">
                            <img class="ratio ratio-1x1" src="../assets/img/ico-mensajes.png" alt=""
                                width="100%" height="70%">
                        </div>
                        <a href="#" class="btn btn-primary">Gestionar</a>
                    </div>
                </div>
            </div>


        </div>
    </div>

      </div>
    `;
  }
  static get styles() {   
    return [stylesSscss];
  }
}

customElements.define('home-component', Home);
