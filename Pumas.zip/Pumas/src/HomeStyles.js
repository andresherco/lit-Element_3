import { css } from 'lit';

export default css`

* {
    box-sizing: border-box;
    padding: 0;
    margin: 0;
}

body{
    background-image: url(/_imagenes/Recurso_1.png);
    background-size: cover;
    backdrop-filter: blur(10px);                
}

.nav {
    background-color: #ffffff;
    width: 100%;
    height: 14vh;
    margin-bottom: 0%;
}

.rectangule_outer {
    width: 35%;
    height: 100%;
    background-color: #f10a0a;
    border-radius: 0% 0% 50px 0%;
    padding: 20px 20px 0px 20px;

}

.circle {
    position: absolute;
    top: 4px;
    left: 9px;
}

.rectangule_inner {
    width: 90%;
    height: 60%;
    background-color: #ffffff;
    border: 1px solid white;
    border-radius: 20px 0% 30px 20px;
}

.logo {
    position: absolute;
    top: 23px;
    left: 25px;
    width: 50px;
}

.user {
    margin-top: 16px;
    margin-left: 80px;
    font-size: 100%;
    font-weight: 700;
    color: rgb(83, 83, 83);
}
.menu-horizontal {
    width: 400px;
    height: 100%;
    background-color: rgba(136, 134, 134, 0.541);
    margin-left: -10%;
    border-radius: 10px;
}

.menu-horizontal-contenedores {
    color: black;
    font-weight: 600;
    border-radius: 3px;
    width: 95%;
    height: 30px;
}
.btn-danger{
    background-color: white !important;
    border: 1px solid white !important;
}
.btn-danger:hover{
    color: black;
}
.btn-primary{
    background-color: red !important;
    border: 1PX solid red !important;
}
.card-title{
    color: rgba(0, 0, 0, 0.753);
    padding-bottom: 5px !important;
    border-bottom: 2px solid rgba(136, 134, 134, 0.541);
}

.icon-balon {
    top: 5px !important;
    width: 5%;
}

`